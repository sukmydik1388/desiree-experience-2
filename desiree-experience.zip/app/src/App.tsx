import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Menu, X, Mail, MapPin, Clock, ChevronRight, 
  Heart, Sparkles, Shield, Calendar, Globe, 
  Phone, Send, Star, Lock, User
} from 'lucide-react';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const mainRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLElement>(null);

  // Navigation links
  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Availability', href: '#availability' },
    { label: 'Etiquette', href: '#etiquette' },
    { label: 'Tours', href: '#tours' },
    { label: 'Contact', href: '#contact' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Services', href: '#services' },
  ];

  // Scroll to section handler
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  // Navigation visibility on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (navRef.current) {
        if (window.scrollY > 100) {
          navRef.current.classList.add('bg-dark/90', 'backdrop-blur-md');
        } else {
          navRef.current.classList.remove('bg-dark/90', 'backdrop-blur-md');
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Initialize GSAP animations
  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero animations
      gsap.fromTo('.hero-eyebrow', 
        { x: -40, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.8, delay: 0.3, ease: 'power2.out' }
      );
      gsap.fromTo('.hero-title span',
        { y: 28, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, stagger: 0.06, delay: 0.5, ease: 'power2.out' }
      );
      gsap.fromTo('.hero-subtitle',
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7, delay: 0.9, ease: 'power2.out' }
      );
      gsap.fromTo('.hero-cta',
        { y: 18, opacity: 0, scale: 0.98 },
        { y: 0, opacity: 1, scale: 1, duration: 0.6, delay: 1.1, ease: 'power2.out' }
      );

      // Section reveal animations
      const sections = document.querySelectorAll('.reveal-section');
      sections.forEach((section) => {
        gsap.fromTo(section,
          { y: 40, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: section,
              start: 'top 80%',
              toggleActions: 'play none none none',
            }
          }
        );
      });

      // Service cards stagger
      gsap.fromTo('.service-card',
        { y: 40, opacity: 0, scale: 0.985 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '#services',
            start: 'top 70%',
            toggleActions: 'play none none none',
          }
        }
      );

      // Testimonial cards stagger
      gsap.fromTo('.testimonial-card',
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '#testimonials',
            start: 'top 70%',
            toggleActions: 'play none none none',
          }
        }
      );

      // Gallery tiles animation
      gsap.fromTo('.gallery-tile',
        { opacity: 0, scale: 0.96 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.7,
          stagger: 0.08,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: '#gallery',
            start: 'top 70%',
            toggleActions: 'play none none none',
          }
        }
      );

    }, mainRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={mainRef} className="relative min-h-screen bg-dark">
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Navigation */}
      <nav ref={navRef} className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
        <div className="flex items-center justify-between px-6 lg:px-12 py-5">
          {/* Logo */}
          <a href="#" className="font-heading text-xl lg:text-2xl text-cream tracking-tight">
            The Desiree Experience
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => scrollToSection(link.href)}
                className="font-label text-xs uppercase tracking-[0.12em] text-cream/70 hover:text-gold transition-colors"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 text-cream"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 right-0 bg-dark/95 backdrop-blur-lg border-t border-cream/10">
            <div className="flex flex-col py-6 px-6">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => scrollToSection(link.href)}
                  className="py-3 font-label text-sm uppercase tracking-[0.12em] text-cream/80 hover:text-gold transition-colors text-left"
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => {
                  setShowBookingModal(true);
                  setIsMenuOpen(false);
                }}
                className="mt-4 btn-primary text-center"
              >
                Book Now
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Floating Book Button */}
      <button
        onClick={() => setShowBookingModal(true)}
        className="fixed bottom-6 right-6 z-40 btn-primary shadow-gold hidden lg:block"
      >
        Book Now
      </button>

      {/* Section 1: Hero */}
      <section id="hero" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/hero_desiree.jpg"
            alt="Desiree"
            className="w-full h-full object-cover object-[70%_30%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="max-w-[34vw] max-lg:max-w-[90%]">
            <p className="hero-eyebrow text-eyebrow mb-4 opacity-0">
              CHICAGO • INCALLS & OUTCALLS
            </p>
            <h1 className="hero-title font-heading text-hero text-cream mb-6">
              {'The Desiree Experience'.split(' ').map((word, i) => (
                <span key={i} className="inline-block mr-[0.3em] opacity-0">{word}</span>
              ))}
            </h1>
            <p className="hero-subtitle font-body text-base lg:text-lg text-cream/70 mb-8 max-w-[30vw] max-lg:max-w-full opacity-0">
              Personalized experiences built on trust, discretion, and chemistry.
            </p>
            <div className="hero-cta flex flex-wrap gap-4 opacity-0">
              <button onClick={() => setShowBookingModal(true)} className="btn-primary">
                Book an Appointment
              </button>
              <button onClick={() => scrollToSection('#about')} className="btn-secondary">
                Explore the Experience
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Your Experience */}
      <section id="experience" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/experience_desiree.jpg"
            alt="Your Experience"
            className="w-full h-full object-cover object-[75%_35%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="reveal-section max-w-[34vw] max-lg:max-w-[90%]">
            <h2 className="font-heading text-h2 text-cream mb-6">
              Your Experience
            </h2>
            <p className="font-body text-base lg:text-lg text-cream/70 mb-8 max-w-[32vw] max-lg:max-w-full">
              Every session is tailored to your comfort level. Clear communication, mutual respect, and a calm, inviting space—so you can actually relax.
            </p>
            <button onClick={() => scrollToSection('#availability')} className="btn-secondary">
              See Availability
            </button>
          </div>
        </div>
      </section>

      {/* Section 3: About */}
      <section id="about" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/about_desiree.jpg"
            alt="About Desiree"
            className="w-full h-full object-cover object-[65%_30%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="reveal-section max-w-[34vw] max-lg:max-w-[90%]">
            <h2 className="font-heading text-h2 text-cream mb-6">
              About
            </h2>
            <p className="font-body text-base lg:text-lg text-cream/70 mb-8 max-w-[32vw] max-lg:max-w-full">
              I'm Desiree—curious, well-read, and genuinely interested in people. I split my time between Chicago and select tours. When we meet, you'll find me present, warm, and easy to talk to.
            </p>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2 text-cream/60">
                <User size={16} className="text-gold" />
                <span className="font-body text-sm">5'4" • Blonde • Blue Eyes</span>
              </div>
            </div>
            <button onClick={() => scrollToSection('#tours')} className="btn-secondary">
              View Tours
            </button>
          </div>
        </div>
      </section>

      {/* Section 4: Availability */}
      <section id="availability" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/availability_desiree.jpg"
            alt="Availability"
            className="w-full h-full object-cover object-[70%_40%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="reveal-section max-w-[34vw] max-lg:max-w-[90%]">
            <h2 className="font-heading text-h2 text-cream mb-6">
              Availability
            </h2>
            <p className="font-body text-base lg:text-lg text-cream/70 mb-8 max-w-[32vw] max-lg:max-w-full">
              Preferred sessions are 90 minutes or longer. Shorter meetings are available for returning friends. Advance notice is always appreciated.
            </p>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2 text-cream/60">
                <Clock size={16} className="text-gold" />
                <span className="font-body text-sm">By Appointment Only</span>
              </div>
            </div>
            <button onClick={() => setShowBookingModal(true)} className="btn-secondary">
              Request a Date
            </button>
          </div>
        </div>
      </section>

      {/* Section 5: Etiquette */}
      <section id="etiquette" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/etiquette_desiree.jpg"
            alt="Etiquette"
            className="w-full h-full object-cover object-[72%_30%]"
          />
          <div className="absolute inset-0 gradient-overlay-strong" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="reveal-section max-w-[40vw] max-lg:max-w-[90%]">
            <h2 className="font-heading text-h2 text-cream mb-4">
              Etiquette
            </h2>
            <div className="hairline-gold mb-8 w-[34vw] max-lg:w-full" />
            
            <div className="space-y-5">
              {[
                'Respect the boundaries we agree on.',
                'Arrive clean and on time.',
                'Place the donation in an unsealed envelope at the start.',
                'Communication stays polite and clear.',
                'Discretion is mutual—and non-negotiable.',
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-gold mt-2 flex-shrink-0" />
                  <p className="font-body text-base text-cream/80">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Tours */}
      <section id="tours" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/tours_desiree.jpg"
            alt="Tours"
            className="w-full h-full object-cover object-[68%_35%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="reveal-section max-w-[34vw] max-lg:max-w-[90%]">
            <h2 className="font-heading text-h2 text-cream mb-6">
              Tours
            </h2>
            <p className="font-body text-base lg:text-lg text-cream/70 mb-8 max-w-[32vw] max-lg:max-w-full">
              I travel to major cities by request. If you'd like me to visit your city, send a tour invitation with preferred dates and a deposit.
            </p>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2 text-cream/60">
                <Globe size={16} className="text-gold" />
                <span className="font-body text-sm">FMTY Available</span>
              </div>
            </div>
            <button onClick={() => scrollToSection('#contact')} className="btn-secondary">
              Request a Tour
            </button>
          </div>
        </div>
      </section>

      {/* Section 7: Contact */}
      <section id="contact" className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/contact_desiree.jpg"
            alt="Contact"
            className="w-full h-full object-cover object-[70%_30%]"
          />
          <div className="absolute inset-0 gradient-overlay-left" />
        </div>

        <div className="relative z-10 h-full flex flex-col justify-center px-8 lg:px-[8vw]">
          <div className="max-w-[420px] max-lg:max-w-full">
            <div className="reveal-section mb-6">
              <h2 className="font-heading text-h2 text-cream mb-4">
                Contact
              </h2>
              <p className="font-body text-base text-cream/70">
                Introduce yourself. Share what you're looking for. I reply to thoughtful messages within 24–48 hours.
              </p>
            </div>

            <form className="reveal-section bg-dark/55 backdrop-blur-sm border border-cream/15 rounded-lg p-6 space-y-4">
              <div>
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream placeholder:text-cream/40 font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream placeholder:text-cream/40 font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <input
                  type="text"
                  placeholder="Your City"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream placeholder:text-cream/40 font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <textarea
                  placeholder="Your Message"
                  rows={4}
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream placeholder:text-cream/40 font-body text-sm focus:outline-none focus:border-gold transition-colors resize-none"
                />
              </div>
              <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
                <Send size={14} />
                Send Inquiry
              </button>
            </form>

            <div className="reveal-section mt-6 flex items-center gap-6 text-cream/60">
              <div className="flex items-center gap-2">
                <Mail size={16} className="text-gold" />
                <span className="font-body text-sm">hello@desiree-experience.com</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-gold" />
                <span className="font-body text-sm">Chicago, IL</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 8: Gallery */}
      <section id="gallery" className="min-h-screen bg-dark py-20 lg:py-32">
        <div className="px-8 lg:px-[6vw]">
          <div className="reveal-section mb-12">
            <h2 className="font-heading text-h2 text-cream mb-2">Gallery</h2>
            <p className="font-body text-cream/60">A few favorite moments.</p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            <div className="gallery-tile col-span-2 lg:col-span-1 row-span-1 aspect-[3/2] lg:aspect-auto lg:h-[34vh] rounded-lg overflow-hidden">
              <img src="/gallery_01.jpg" alt="Gallery 1" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="gallery-tile aspect-[2/3] lg:h-[34vh] rounded-lg overflow-hidden">
              <img src="/gallery_02.jpg" alt="Gallery 2" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="gallery-tile col-span-2 lg:col-span-1 aspect-[3/2] lg:aspect-auto lg:h-[34vh] rounded-lg overflow-hidden">
              <img src="/gallery_03.jpg" alt="Gallery 3" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="gallery-tile aspect-[2/3] lg:h-[38vh] rounded-lg overflow-hidden">
              <img src="/gallery_04.jpg" alt="Gallery 4" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="gallery-tile col-span-2 lg:col-span-1 aspect-[3/2] lg:aspect-auto lg:h-[38vh] rounded-lg overflow-hidden">
              <img src="/gallery_05.jpg" alt="Gallery 5" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="gallery-tile aspect-[2/3] lg:h-[38vh] rounded-lg overflow-hidden">
              <img src="/gallery_06.jpg" alt="Gallery 6" className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
          </div>
        </div>
      </section>

      {/* Section 9: Red Room CTA */}
      <section className="section-pinned">
        <div className="absolute inset-0">
          <img
            src="/redroom_desiree.jpg"
            alt="Ready to begin"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-burgundy/35" />
        </div>

        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-8">
          <div className="reveal-section">
            <h2 className="font-heading text-h2 text-cream mb-8">
              Ready to begin?
            </h2>
            <button onClick={() => setShowBookingModal(true)} className="btn-primary">
              Book an Appointment
            </button>
          </div>
        </div>
      </section>

      {/* Section 10: Services */}
      <section id="services" className="min-h-screen bg-dark py-20 lg:py-32">
        <div className="px-8 lg:px-[8vw]">
          <div className="lg:flex lg:gap-16">
            {/* Left sticky column */}
            <div className="lg:w-[38vw] lg:sticky lg:top-32 lg:self-start mb-12 lg:mb-0">
              <div className="reveal-section">
                <h2 className="font-heading text-h2 text-cream mb-6">Services</h2>
                <p className="font-body text-base text-cream/70 mb-8 max-w-md">
                  I offer a range of experiences—from relaxed companionship to curated fantasy sessions. If you're unsure what fits, let's talk.
                </p>
                <button onClick={() => setShowBookingModal(true)} className="btn-secondary">
                  Request a Session
                </button>
              </div>
            </div>

            {/* Right scrollable services */}
            <div className="lg:w-[46vw] space-y-6">
              {[
                {
                  title: 'Social Time',
                  desc: 'Dinner, events, travel. Conversation that flows.',
                  icon: Heart,
                },
                {
                  title: 'Private Companionship',
                  desc: 'Unrushed, intimate, and entirely private.',
                  icon: Lock,
                },
                {
                  title: 'Overnights & Travel',
                  desc: 'Extended time for deeper connection.',
                  icon: Calendar,
                },
                {
                  title: 'Fantasy & Roleplay',
                  desc: 'Scenes built on trust, clarity, and consent.',
                  icon: Sparkles,
                },
                {
                  title: 'Couples Sessions',
                  desc: 'A calm, experienced presence for two.',
                  icon: User,
                },
                {
                  title: 'Virtual Connection',
                  desc: 'Video calls and personalized content.',
                  icon: Phone,
                },
              ].map((service, i) => (
                <div key={i} className="service-card bg-cream/[0.04] border border-cream/10 rounded-xl p-6 hover:border-gold/40 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-gold/10 rounded-lg">
                      <service.icon size={20} className="text-gold" />
                    </div>
                    <div>
                      <h3 className="font-label text-sm uppercase tracking-[0.12em] text-cream mb-2">
                        {service.title}
                      </h3>
                      <p className="font-body text-sm text-cream/60">{service.desc}</p>
                    </div>
                  </div>
                  <div className="hairline-gold mt-4 ml-14" />
                </div>
              ))}

              {/* Additional Services */}
              <div className="service-card bg-cream/[0.04] border border-cream/10 rounded-xl p-6">
                <h3 className="font-label text-sm uppercase tracking-[0.12em] text-cream mb-4">
                  Specialty Experiences
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    'Massage', 'Domination', 'BDSM', 'Prostate',
                    'Pegging', 'Bondage', 'Impact Play', 'Worship',
                    'Feet Fetish', 'Humiliation', 'Slave Training', 'Long-term Arrangements'
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <ChevronRight size={12} className="text-gold" />
                      <span className="font-body text-sm text-cream/70">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 11: Testimonials */}
      <section id="testimonials" className="min-h-screen bg-dark py-20 lg:py-32">
        <div className="px-8 lg:px-[8vw]">
          <div className="reveal-section text-center mb-16">
            <h2 className="font-heading text-h2 text-cream mb-2">What friends say</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                quote: "Desiree makes you feel like the only person in the room.",
                author: "A Gentleman",
              },
              {
                quote: "Discreet, punctual, and genuinely kind. An unforgettable experience.",
                author: "Regular Client",
              },
              {
                quote: "The most relaxed I've felt in months. Truly transformative.",
                author: "Grateful Friend",
              },
            ].map((testimonial, i) => (
              <div key={i} className="testimonial-card bg-cream/[0.05] border border-cream/10 rounded-xl p-8">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} size={14} className="text-gold fill-gold" />
                  ))}
                </div>
                <p className="font-body text-cream/80 mb-6 italic">"{testimonial.quote}"</p>
                <p className="font-label text-xs uppercase tracking-[0.12em] text-cream/50">
                  — {testimonial.author}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 12: Footer */}
      <footer className="bg-dark border-t border-cream/10 py-16 lg:py-24">
        <div className="px-8 lg:px-[8vw]">
          <div className="lg:flex lg:justify-between lg:items-start mb-16">
            <div className="mb-8 lg:mb-0">
              <h3 className="font-heading text-2xl text-cream mb-2">
                The Desiree Experience
              </h3>
              <p className="font-body text-cream/60">Turning dreams into memories.</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-12">
              {[
                { label: 'About', href: '#about' },
                { label: 'Availability', href: '#availability' },
                { label: 'Etiquette', href: '#etiquette' },
                { label: 'Tours', href: '#tours' },
                { label: 'Contact', href: '#contact' },
                { label: 'Gallery', href: '#gallery' },
                { label: 'Services', href: '#services' },
                { label: 'Book', href: '#', onClick: () => setShowBookingModal(true) },
              ].map((link, i) => (
                <button
                  key={i}
                  onClick={() => link.onClick ? link.onClick() : scrollToSection(link.href)}
                  className="font-body text-sm text-cream/60 hover:text-gold transition-colors text-left"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          <div className="text-center mb-8">
            <button onClick={() => setShowBookingModal(true)} className="btn-primary">
              Book an Appointment
            </button>
          </div>

          <div className="hairline mb-6" />

          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="font-body text-xs text-cream/40">
              © 2026 The Desiree Experience. All rights reserved.
            </p>
            <div className="flex items-center gap-2 text-cream/40">
              <Shield size={14} />
              <span className="font-body text-xs">Discretion Guaranteed</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Booking Modal */}
      {showBookingModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-dark/90 backdrop-blur-lg"
            onClick={() => setShowBookingModal(false)}
          />
          <div className="relative bg-dark-light border border-cream/15 rounded-2xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowBookingModal(false)}
              className="absolute top-4 right-4 text-cream/60 hover:text-cream"
            >
              <X size={24} />
            </button>

            <h3 className="font-heading text-2xl text-cream mb-2">Book an Appointment</h3>
            <p className="font-body text-sm text-cream/60 mb-6">
              Fill out the form below and I'll get back to you within 24-48 hours.
            </p>

            <form className="space-y-4">
              <div>
                <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                  Your Name
                </label>
                <input
                  type="text"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                  Email Address
                </label>
                <input
                  type="email"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div>
                <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                  Phone (Optional)
                </label>
                <input
                  type="tel"
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors"
                  />
                </div>
                <div>
                  <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                    Session Length
                  </label>
                  <select className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors">
                    <option value="">Select...</option>
                    <option value="1h">1 Hour</option>
                    <option value="90m">90 Minutes</option>
                    <option value="2h">2 Hours</option>
                    <option value="3h">3 Hours</option>
                    <option value="overnight">Overnight</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                  Location
                </label>
                <select className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors">
                  <option value="">Select...</option>
                  <option value="incall">Chicago Incall</option>
                  <option value="outcall">Chicago Outcall</option>
                  <option value="tour">Tour City</option>
                  <option value="fmt">FMTY</option>
                </select>
              </div>
              <div>
                <label className="font-label text-xs uppercase tracking-[0.12em] text-cream/60 mb-2 block">
                  Special Requests / Interests
                </label>
                <textarea
                  rows={3}
                  className="w-full bg-dark/50 border border-cream/20 rounded-lg px-4 py-3 text-cream font-body text-sm focus:outline-none focus:border-gold transition-colors resize-none"
                />
              </div>
              <button type="submit" className="btn-primary w-full">
                Submit Request
              </button>
            </form>

            <p className="font-body text-xs text-cream/40 text-center mt-4">
              All information is kept strictly confidential.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
