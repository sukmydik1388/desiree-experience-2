# The Desiree Experience

A sophisticated, elegant website for a luxury companionship and personalized fantasy experience provider based in Chicago.

![Website Preview](./public/hero_desiree.jpg)

## Live Site

**URL:** [https://goq2eswalxigy.ok.kimi.link](https://goq2eswalxigy.ok.kimi.link)

## Features

- **Responsive Design** — Works beautifully on desktop, tablet, and mobile
- **Smooth Animations** — GSAP-powered scroll animations and transitions
- **Booking System** — Full-featured booking modal with form validation
- **Gallery** — Curated image mosaic showcasing the experience
- **Services Showcase** — Comprehensive list of offerings
- **Testimonials** — Client reviews with elegant card design
- **Contact Form** — Easy inquiry submission
- **Discretion-Focused** — Privacy and professionalism emphasized throughout

## Tech Stack

- **Framework:** React 18 + TypeScript
- **Build Tool:** Vite
- **Styling:** Tailwind CSS
- **Animations:** GSAP + ScrollTrigger
- **Icons:** Lucide React
- **UI Components:** shadcn/ui

## Project Structure

```
├── public/              # Static assets (images)
│   ├── hero_desiree.jpg
│   ├── about_desiree.jpg
│   ├── gallery_01.jpg - gallery_06.jpg
│   └── ...
├── src/
│   ├── App.tsx          # Main application component
│   ├── App.css          # Custom styles
│   ├── index.css        # Global styles & Tailwind
│   └── main.tsx         # Entry point
├── index.html           # HTML template
├── tailwind.config.js   # Tailwind configuration
├── vite.config.ts       # Vite configuration
└── package.json         # Dependencies
```

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/desiree-experience.git
cd desiree-experience
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser.

### Building for Production

```bash
npm run build
```

The built files will be in the `dist/` folder, ready for deployment.

## Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Connect repository on [Vercel](https://vercel.com)
3. Auto-deploys on every push

### Netlify

1. Drag and drop the `dist` folder, or
2. Connect GitHub repository for auto-deploy

### Custom Hosting

Upload the contents of the `dist/` folder to your web server.

## Customization

### Colors

Edit `tailwind.config.js` or `src/index.css`:

- **Background:** `#0B0B0D` (dark)
- **Text:** `#F4F1EA` (cream)
- **Accent:** `#C9A86A` (gold)

### Images

Replace images in the `public/` folder with your own. Maintain the same filenames or update references in `App.tsx`.

### Content

Edit text content directly in `src/App.tsx`. Each section is clearly labeled with comments.

## SEO & Meta Tags

Update the following in `index.html`:

- `<title>` — Page title
- `<meta name="description">` — Site description
- Open Graph tags for social sharing

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

All rights reserved. This is a private project.

---

**Questions or need help?** Contact the developer or refer to the [Vite documentation](https://vitejs.dev/guide/) and [React documentation](https://react.dev/).
